# Learning Bot (Geode mod for Geometry Dash 2.2074)

A robot that plays your level and **learns from every attempt**.

## Platforms
Windows, macOS, iOS (iPhone/iPad) and Android, all from the same code.
On phones the panel is automatically bigger with thumb-sized buttons and sits clear of the notch.
The "Panel size" setting lets you scale it further.

## Build

### Easiest: build everything with GitHub (no setup, works for iPhone)
1. Make a free GitHub account and create a new repository.
2. Upload this whole folder (including the `.github` folder) to it.
3. Open the **Actions** tab -> "Build Learning Bot (all platforms)" -> wait for it to finish.
4. Download **Build Output**: one `.geode` file that contains Windows, Mac, iOS and Android.

### PC/Mac only, on your own computer
1. Install the Geode SDK + CLI (https://docs.geode-sdk.org/getting-started/).
2. In this folder run `geode build`.
3. The `.geode` file is made in `build/`.

## Installing
- **Windows / Mac:** put the `.geode` file in the `geode/mods` folder of Geometry Dash (or open it with Geode).
- **iPhone/iPad:** you need Geode installed on iOS first (see https://geode-sdk.org). Then
  copy the `.geode` file into Geode's mods folder on the device (Files app / sideload tool) and restart GD.
- **Android:** put it in `Android/media/com.geode.launcher/game/geode/mods`.

## Using it
- A panel appears bottom-left in every level. The bot **never starts by itself**.
- **Start** begins at the next attempt (if you press it mid-attempt, that attempt just isn't learned from).
- **Pause / Resume / Stop** do what they say. **Press jump yourself** and the bot pauses instantly.
- **Clear** (with confirmation) wipes this level's memory: it then remembers nothing at all.
- Settings: show/hide the panel, panel opacity, exploration (0 = only repeats what it learned).

## How it really learns
- Each frame it "sees" the next hazard/block group ahead: type, width, height, distance, speed.
- When it's on the ground and that picture changes, it picks **wait or jump** (from its learned values + curiosity).
- Crash -> the choices right before the crash get blamed (the closest ones most).
- Getting past a hazard group alive -> the choices that got it there get rewarded.
- Same pattern anywhere in the level = same situation, so one lesson helps on every identical spike group.
- Memory is saved per level in the mod's save folder (`levels/<level id>.txt`) and reloaded next time.
- It does **not** touch level data, physics or the player: it only sends jump presses.

## Honest limits (v1)
- Cube mode only (incl. mini and upside-down). In ship/UFO/ball/wave/etc. the bot steps aside ("not supported - you play"), and attempts containing those parts aren't learned from.
- No orbs/pads/dual-mode control yet; slopes are ignored.
- Needs a steady framerate (60+ fps) for best results.
- Phone and PC use the exact same bot; I couldn't test on a real iPhone from here.
- Written against Geode 4.x / GD 2.2074 bindings but not compiled here, so a field or signature may need a small rename on first build (the error will point at the exact line).
