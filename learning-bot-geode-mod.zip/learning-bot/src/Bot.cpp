#include "Bot.hpp"
#include "Panel.hpp"

using namespace geode::prelude;

static constexpr float kLookAhead = 240.f;  // how far ahead it can see (units, 30 = 1 block)
static constexpr float kBucket = 10.f;      // distance is grouped into 10-unit steps
static constexpr float kBlameRange = 220.f; // crashes blame decisions made this close before
static constexpr int kHoldFrames = 3;       // a jump "tap" lasts a few frames

Bot& Bot::get() {
    static Bot b;
    return b;
}

static std::string sanitize(std::string s) {
    for (auto& c : s) {
        if (!std::isalnum(static_cast<unsigned char>(c))) c = '_';
    }
    return s;
}

std::filesystem::path Bot::memPath() const {
    return Mod::get()->getSaveDir() / "levels" / (levelKey + ".txt");
}

void Bot::save() {
    if (brain) brain->save(memPath());
}

// ---------------------------------------------------------------- lifecycle

void Bot::onLevelLoaded(PlayLayer* pl) {
    panel = nullptr;
    state = BotState::Stopped; // never auto-starts
    died = false;
    attemptClean = false;
    decisions.clear();
    pendingEndX = -1.f;
    lastKey = UINT64_MAX;
    holdFrames = 0;
    vision = Vision();

    auto* lvl = pl->m_level;
    int id = lvl->m_levelID.value();
    levelKey = id > 0 ? fmt::format("id_{}", id)
                      : "local_" + sanitize(std::string(lvl->m_levelName));

    std::error_code ec;
    std::filesystem::create_directories(Mod::get()->getSaveDir() / "levels", ec);

    brain = std::make_unique<Brain>();
    brain->load(memPath());
    buildCache(pl);
}

void Bot::buildCache(PlayLayer* pl) {
    obst.clear();
    if (!pl->m_objects) return;
    for (auto* obj : CCArrayExt<GameObject*>(pl->m_objects)) {
        if (!obj) continue;
        auto t = obj->m_objectType;
        bool hazard = t == GameObjectType::Hazard;
        bool solid = t == GameObjectType::Solid;
        if (!hazard && !solid) continue;
        auto r = obj->getObjectRect();
        obst.push_back({r.getMinX(), r.getMaxX(), r.getMinY(), r.getMaxY(), solid});
    }
    std::sort(obst.begin(), obst.end(), [](Obst const& a, Obst const& b) { return a.minX < b.minX; });
}

void Bot::beforeReset(PlayLayer* pl) {
    if (!brain) return;
    if (died && attemptClean) {
        blameDeath();
        brain->attempts++;
        brain->best = std::max(brain->best, deathPct);
        save();
    }
    died = false;
}

void Bot::afterReset(PlayLayer* pl) {
    if (!brain) return;
    decisions.clear();
    pendingEndX = -1.f;
    windowStart = 0;
    lastKey = UINT64_MAX;
    holdFrames = 0;
    died = false;
    // A clean attempt = the bot was running from the very start of this attempt.
    attemptClean = state == BotState::Running && pl->getCurrentPercent() < 1.f;
    vision.action = "-";
}

void Bot::onDeath(PlayLayer* pl) {
    if (!brain) return;
    died = true;
    deathX = pl->m_player1->getPositionX();
    deathPct = pl->getCurrentPercent();
    holdFrames = 0;
}

void Bot::onComplete(PlayLayer* pl) {
    if (!brain) return;
    if (state == BotState::Running && attemptClean) {
        rewardWindow();
        brain->attempts++;
        brain->best = 100.f;
        save();
    }
    holdFrames = 0;
    state = BotState::Stopped;
    vision.action = "Level complete!";
}

void Bot::onLeave(PlayLayer* pl) {
    if (brain) save();
    brain.reset();
    panel = nullptr;
    state = BotState::Stopped;
    holdFrames = 0;
}

void Bot::onHumanInput() {
    // The player pressed jump while the bot was running: instant takeover.
    state = BotState::PlayerControl;
    attemptClean = false; // a mixed attempt teaches the bot nothing true
    holdFrames = 0;       // don't send a release; it could cancel the player's press
}

// ---------------------------------------------------------------- controls

void Bot::start() {
    if (!brain) return;
    state = BotState::Running;
    // If we're still at the very start of an attempt, this attempt counts.
    if (vision.nowPct < 1.f && !died && decisions.empty()) attemptClean = true;
}

void Bot::pause() {
    if (state != BotState::Running) return;
    state = BotState::Paused;
    attemptClean = false;
    if (auto* pl = PlayLayer::get()) {
        if (holdFrames > 0) release(pl);
    }
    holdFrames = 0;
}

void Bot::resume() {
    if (!brain) return;
    state = BotState::Running; // this attempt stays unclean; the next reset is clean again
}

void Bot::stop() {
    state = BotState::Stopped;
    attemptClean = false;
    if (auto* pl = PlayLayer::get()) {
        if (holdFrames > 0) release(pl);
    }
    holdFrames = 0;
    vision.action = "-";
}

void Bot::clearMemory() {
    if (!brain) return;
    brain->clear();
    decisions.clear();
    pendingEndX = -1.f;
    lastKey = UINT64_MAX;
    attemptClean = false; // this attempt was partly played with old memory
    std::error_code ec;
    std::filesystem::remove(memPath(), ec);
}

// ---------------------------------------------------------------- input

void Bot::press(PlayLayer* pl) {
    injecting = true;
    pl->handleButton(true, 1, true);
    injecting = false;
    holdFrames = kHoldFrames;
}

void Bot::release(PlayLayer* pl) {
    injecting = true;
    pl->handleButton(false, 1, true);
    injecting = false;
}

// ---------------------------------------------------------------- learning

// A hazard group was passed alive: the choices made on the way get rewarded.
void Bot::rewardWindow() {
    if (!brain) return;
    for (size_t i = windowStart; i < decisions.size(); i++) {
        auto const& d = decisions[i];
        if (d.action == 1) brain->update(d.key, 1, +1.f, 0.5f);
        else brain->update(d.key, 0, +0.15f, 0.25f);
    }
    windowStart = decisions.size();
    pendingEndX = -1.f;
}

// Crashed: blame recent choices, the closest ones the most.
void Bot::blameDeath() {
    if (!brain) return;
    for (auto const& d : decisions) {
        float dist = deathX - d.x;
        if (dist > kBlameRange || dist < -5.f) continue;
        float w = std::exp(-std::max(dist, 0.f) / 70.f);
        brain->update(d.key, d.action, -1.f, 0.6f * w);
    }
}

// ---------------------------------------------------------------- perception

static std::string modeName(PlayerObject* p, bool& supported) {
    supported = false;
    if (p->m_isShip) return "Ship";
    if (p->m_isBird) return "UFO";
    if (p->m_isBall) return "Ball";
    if (p->m_isDart) return "Wave";
    if (p->m_isRobot) return "Robot";
    if (p->m_isSpider) return "Spider";
    if (p->m_isSwing) return "Swing";
    supported = true;
    return "Cube";
}

void Bot::perceive(PlayLayer* pl) {
    auto& v = vision;
    auto* p = pl->m_player1;
    v.grounded = p->m_isOnGround;
    v.mode = modeName(p, v.supported);
    v.nowPct = pl->getCurrentPercent();
    v.hasTarget = false;
    if (!v.supported || obst.empty()) return;

    float scale = std::abs(p->getScaleY());
    float half = 15.f * scale;
    float px = p->getPositionX();
    float py = p->getPositionY();
    bool up = p->m_isUpsideDown;
    float feet = up ? py + half : py - half;
    float right = px + half;
    auto relY = [&](float y) { return up ? feet - y : y - feet; };

    auto it = std::lower_bound(obst.begin(), obst.end(), px - 60.f,
                               [](Obst const& o, float x) { return o.minX < x; });

    bool have = false, anyHazard = false;
    float cMin = 0, cMax = 0, cTop = 0;
    int count = 0;
    for (; it != obst.end() && it->minX < right + kLookAhead; ++it) {
        if (it->maxX < px - half) continue; // already behind us
        float a = relY(it->minY), b = relY(it->maxY);
        float rb = std::min(a, b), rt = std::max(a, b);
        if (rb > 60.f || rt < 8.f) continue; // not in the lane we're running in
        if (!have) {
            if (it->minX < right - 6.f) continue; // beside us, not ahead
            have = true;
            cMin = it->minX;
            cMax = it->maxX;
            cTop = rt;
            anyHazard = !it->solid;
            count = 1;
        } else if (it->minX - cMax < 30.f) { // close enough = same group (e.g. triple spike)
            cMax = std::max(cMax, it->maxX);
            cTop = std::max(cTop, rt);
            anyHazard = anyHazard || !it->solid;
            count++;
        } else {
            break;
        }
    }
    if (!have) return;

    v.hasTarget = true;
    v.hazard = anyHazard;
    v.count = count;
    v.dist = std::max(0.f, cMin - right);
    v.width = cMax - cMin;
    v.height = cTop;
    v.clusterMinX = cMin;
    v.clusterMaxX = cMax;

    // The "situation" the bot learns about. Same pattern anywhere in the level = same situation,
    // so what it learns on one spike group helps on every identical one.
    auto clampi = [](int x, int lo, int hi) { return std::max(lo, std::min(hi, x)); };
    uint64_t tType = anyHazard ? 0 : 1;
    uint64_t wB = clampi(int(std::round(v.width / 15.f)), 1, 12);
    uint64_t hB = clampi(int(std::round(v.height / 15.f)), 1, 10);
    uint64_t spd = clampi(int(std::round(p->m_playerSpeed * 10.f)), 5, 20);
    uint64_t mini = scale < 0.9f ? 1 : 0;
    uint64_t flip = up ? 1 : 0;
    uint64_t dB = clampi(int(v.dist / kBucket), 0, 63);
    v.key = ((((((tType * 16 + wB) * 16 + hB) * 32 + spd) * 2 + mini) * 2 + flip) * 64) + dB;
}

// ---------------------------------------------------------------- the main loop

void Bot::tick(PlayLayer* pl) {
    if (!brain || !pl || !pl->m_player1) return;
    auto* p = pl->m_player1;

    // finish a jump "tap"
    if (holdFrames > 0 && --holdFrames == 0) release(pl);

    perceive(pl);

    if (state == BotState::Running && !p->m_isDead && !died) {
        auto& v = vision;
        if (!v.supported) {
            // Not a cube part: the bot doesn't pretend. You play this bit.
            attemptClean = false;
            v.action = "not supported - you play";
        } else {
            // 1) did we just get past a hazard group alive? reward the choices that got us there
            if (pendingEndX > 0.f) {
                float half = 15.f * std::abs(p->getScaleY());
                if (p->getPositionX() - half > pendingEndX + 6.f) rewardWindow();
            }
            // 2) decide (only when grounded and the situation changed)
            if (!v.hasTarget) {
                v.action = "wait";
                lastKey = UINT64_MAX;
            } else if (!v.grounded) {
                v.action = "in air";
            } else if (v.key != lastKey) {
                lastKey = v.key;
                float expl = static_cast<float>(Mod::get()->getSettingValue<double>("exploration"));
                int a = brain->choose(v.key, expl);
                decisions.push_back({v.key, a, p->getPositionX()});
                if (pendingEndX < 0.f) {
                    pendingEndX = v.clusterMaxX;
                    windowStart = decisions.size() - 1;
                }
                if (a == 1) {
                    press(pl);
                    v.action = "JUMP";
                } else {
                    v.action = "wait";
                }
            }
        }
    } else if (state != BotState::Running) {
        vision.action = "-";
    }

    if (panel) panel->refresh();
}
