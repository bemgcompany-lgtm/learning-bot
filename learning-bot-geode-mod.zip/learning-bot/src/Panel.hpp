#pragma once
#include <Geode/Geode.hpp>
#include <string>

// Compact bottom-left panel: what the robot sees + Start/Pause/Resume/Stop/Clear buttons.
class Panel : public cocos2d::CCNode {
public:
    static Panel* create();
    bool init() override;
    void refresh();

private:
    cocos2d::extension::CCScale9Sprite* m_bg = nullptr;
    cocos2d::CCLabelBMFont* m_lines[6] = {};
    std::string m_cache[6];
    cocos2d::CCMenu* m_menu = nullptr;
    CCMenuItemSpriteExtra* m_start = nullptr;
    CCMenuItemSpriteExtra* m_pause = nullptr;
    CCMenuItemSpriteExtra* m_resume = nullptr;
    CCMenuItemSpriteExtra* m_stop = nullptr;
    CCMenuItemSpriteExtra* m_clear = nullptr;

    void onStart(cocos2d::CCObject*);
    void onPause(cocos2d::CCObject*);
    void onResume(cocos2d::CCObject*);
    void onStop(cocos2d::CCObject*);
    void onClear(cocos2d::CCObject*);
    void setLine(int i, std::string const& text, cocos2d::ccColor3B color = {255, 255, 255});
};
