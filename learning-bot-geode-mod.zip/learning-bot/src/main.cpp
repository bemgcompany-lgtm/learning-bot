#include <Geode/Geode.hpp>
#include <Geode/modify/GJBaseGameLayer.hpp>
#include <Geode/modify/PlayLayer.hpp>
#include "Bot.hpp"
#include "Panel.hpp"

using namespace geode::prelude;

class $modify(LBPlayLayer, PlayLayer) {
    void setupHasCompleted() {
        PlayLayer::setupHasCompleted();
        auto& bot = Bot::get();
        bot.onLevelLoaded(this); // loads this level's saved memory; bot starts STOPPED
        auto* panel = Panel::create();
        panel->setID("panel"_spr);
        this->addChild(panel, 1000);
        bot.panel = panel;
    }

    void resetLevel() {
        Bot::get().beforeReset(this); // learn from the attempt that just ended
        PlayLayer::resetLevel();
        Bot::get().afterReset(this);  // start a fresh attempt
    }

    void destroyPlayer(PlayerObject* player, GameObject* object) {
        bool wasDead = m_player1 && m_player1->m_isDead;
        PlayLayer::destroyPlayer(player, object);
        if (!wasDead && m_player1 && m_player1->m_isDead) {
            Bot::get().onDeath(this);
        }
    }

    void postUpdate(float dt) {
        PlayLayer::postUpdate(dt);
        Bot::get().tick(this);
    }

    void levelComplete() {
        PlayLayer::levelComplete();
        Bot::get().onComplete(this);
    }

    void onQuit() {
        Bot::get().onLeave(this);
        PlayLayer::onQuit();
    }
};

// Instant player takeover: if YOU press jump while the bot runs, the bot pauses.
class $modify(LBGameLayer, GJBaseGameLayer) {
    void handleButton(bool down, int button, bool isPlayer1) {
        auto& bot = Bot::get();
        if (down && button == 1 && !bot.injecting && bot.state == BotState::Running && PlayLayer::get()) {
            bot.onHumanInput();
        }
        GJBaseGameLayer::handleButton(down, button, isPlayer1);
    }
};
