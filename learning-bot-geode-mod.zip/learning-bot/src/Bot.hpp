#pragma once
#include <Geode/Geode.hpp>
#include <memory>
#include <string>
#include <vector>
#include "Brain.hpp"

class Panel;

enum class BotState { Stopped, Running, Paused, PlayerControl };

// A hazard or solid block the bot can see (cached once per level).
struct Obst {
    float minX, maxX, minY, maxY;
    bool solid;
};

// Everything the "what the robot sees" panel shows.
struct Vision {
    std::string mode = "Cube";
    bool supported = true;
    bool grounded = true;
    bool hasTarget = false;
    bool hazard = true;
    int count = 0;
    float dist = 0.f;
    float width = 0.f;
    float height = 0.f;
    float clusterMinX = 0.f;
    float clusterMaxX = 0.f;
    float nowPct = 0.f;
    std::string action = "-";
    uint64_t key = 0;
};

class Bot {
public:
    static Bot& get();

    BotState state = BotState::Stopped;
    bool injecting = false; // true while the bot itself sends a jump
    Vision vision;
    std::unique_ptr<Brain> brain;
    Panel* panel = nullptr;

    // lifecycle (called from hooks)
    void onLevelLoaded(PlayLayer* pl);
    void beforeReset(PlayLayer* pl);
    void afterReset(PlayLayer* pl);
    void tick(PlayLayer* pl);
    void onDeath(PlayLayer* pl);
    void onComplete(PlayLayer* pl);
    void onLeave(PlayLayer* pl);
    void onHumanInput();

    // controls (called from the panel buttons)
    void start();
    void pause();
    void resume();
    void stop();
    void clearMemory();

private:
    std::string levelKey;
    std::vector<Obst> obst;
    std::vector<Decision> decisions;
    bool died = false;
    bool attemptClean = false; // only learn from attempts the bot played start-to-finish
    float deathX = 0.f;
    float deathPct = 0.f;
    float pendingEndX = -1.f; // far edge of the hazard group we're currently getting past
    size_t windowStart = 0;
    uint64_t lastKey = UINT64_MAX;
    int holdFrames = 0;

    std::filesystem::path memPath() const;
    void buildCache(PlayLayer* pl);
    void perceive(PlayLayer* pl);
    void press(PlayLayer* pl);
    void release(PlayLayer* pl);
    void rewardWindow();
    void blameDeath();
    void save();
};
