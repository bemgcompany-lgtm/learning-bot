#pragma once
#include <algorithm>
#include <cmath>
#include <cstdint>
#include <filesystem>
#include <fstream>
#include <random>
#include <unordered_map>

// One "situation" the bot has met (what's ahead + how far away it is).
// q[0] = how good "wait" has been here, q[1] = how good "jump" has been here.
struct Cell {
    float q[2] = {0.f, 0.f};
    uint32_t n[2] = {0, 0};
};

// One choice the bot made during the current attempt.
struct Decision {
    uint64_t key;
    int action; // 0 = wait, 1 = jump
    float x;    // where in the level it decided
};

class Brain {
public:
    std::unordered_map<uint64_t, Cell> cells;
    int attempts = 0;
    float best = 0.f;

    // Pick wait/jump for a situation. Uses what it learned + curiosity
    // (curiosity shrinks as the bot gains attempts).
    int choose(uint64_t key, float exploration) {
        Cell& c = cells[key];
        float total = float(c.n[0] + c.n[1]);
        float scale = exploration / (1.f + float(attempts) * 0.03f);
        float b0 = scale * std::sqrt(std::log(total + 2.f) / (float(c.n[0]) + 1.f));
        float b1 = scale * std::sqrt(std::log(total + 2.f) / (float(c.n[1]) + 1.f));
        float s0 = c.q[0] + b0 + noise();
        float s1 = c.q[1] + b1 - 0.12f + noise(); // jumping costs a little: prefer waiting when unsure
        return s1 > s0 ? 1 : 0;
    }

    // Learn: nudge the value of (situation, action) toward a result.
    // target +1 = that choice worked, -1 = that choice led to a crash.
    void update(uint64_t key, int action, float target, float alpha) {
        Cell& c = cells[key];
        c.q[action] += alpha * (target - c.q[action]);
        c.n[action] += 1;
    }

    int situationsLearned() const {
        int n = 0;
        for (auto const& [k, c] : cells) {
            if (c.n[0] + c.n[1] > 0) n++;
        }
        return n;
    }

    int jumpSpotsLearned() const {
        int n = 0;
        for (auto const& [k, c] : cells) {
            if (c.n[1] > 0 && c.q[1] > 0.4f) n++;
        }
        return n;
    }

    void clear() {
        cells.clear();
        attempts = 0;
        best = 0.f;
    }

    bool save(std::filesystem::path const& path) const {
        std::ofstream f(path, std::ios::trunc);
        if (!f) return false;
        f << "GDLB1\n" << attempts << ' ' << best << '\n';
        for (auto const& [k, c] : cells) {
            if (c.n[0] + c.n[1] == 0) continue;
            f << k << ' ' << c.n[0] << ' ' << c.n[1] << ' ' << c.q[0] << ' ' << c.q[1] << '\n';
        }
        return true;
    }

    bool load(std::filesystem::path const& path) {
        clear();
        std::ifstream f(path);
        if (!f) return false;
        std::string magic;
        f >> magic;
        if (magic != "GDLB1") return false;
        f >> attempts >> best;
        uint64_t k;
        Cell c;
        while (f >> k >> c.n[0] >> c.n[1] >> c.q[0] >> c.q[1]) {
            cells[k] = c;
        }
        return true;
    }

private:
    float noise() {
        static std::mt19937 rng{std::random_device{}()};
        static std::uniform_real_distribution<float> d(0.f, 0.02f);
        return d(rng);
    }
};
