#include "Panel.hpp"
#include "Bot.hpp"

using namespace geode::prelude;

static constexpr float kW = 196.f;
#ifdef GEODE_IS_MOBILE
static constexpr float kH = 118.f;  // a little taller for the bigger buttons
static constexpr float kBaseScale = 1.15f;
#else
static constexpr float kH = 108.f;
static constexpr float kBaseScale = 1.0f;
#endif

Panel* Panel::create() {
    auto ret = new Panel();
    if (ret && ret->init()) {
        ret->autorelease();
        return ret;
    }
    CC_SAFE_DELETE(ret);
    return nullptr;
}

bool Panel::init() {
    if (!CCNode::init()) return false;

#if defined(GEODE_IS_IOS)
    this->setPosition(34.f, 10.f); // keep clear of the iPhone notch / rounded corners
#elif defined(GEODE_IS_MOBILE)
    this->setPosition(16.f, 10.f);
#else
    this->setPosition(6.f, 6.f);
#endif
    this->setContentSize({kW, kH});

    m_bg = extension::CCScale9Sprite::create("square02_001.png", {0, 0, 80, 80});
    m_bg->setContentSize({kW, kH});
    m_bg->setAnchorPoint({0, 0});
    m_bg->setColor({0, 0, 0});
    this->addChild(m_bg, -1);

    for (int i = 0; i < 6; i++) {
        auto* l = CCLabelBMFont::create("", "chatFont.fnt");
        l->setAnchorPoint({0, 0.5f});
        l->setScale(0.55f);
        l->setPosition(8.f, kH - 11.f - i * 13.f);
        this->addChild(l);
        m_lines[i] = l;
    }

    m_menu = CCMenu::create();
    m_menu->setPosition(0, 0);
    this->addChild(m_menu);

    auto mk = [&](char const* text, char const* tex, SEL_MenuHandler cb, float x) {
#ifdef GEODE_IS_MOBILE
        // bigger buttons: easy to hit with a thumb
        auto* spr = ButtonSprite::create(text, 54, true, "bigFont.fnt", tex, 30.f, 0.6f);
#else
        auto* spr = ButtonSprite::create(text, 44, true, "bigFont.fnt", tex, 22.f, 0.55f);
#endif
        auto* btn = CCMenuItemSpriteExtra::create(spr, this, cb);
#ifdef GEODE_IS_MOBILE
        btn->setPosition(x, 17.f);
#else
        btn->setPosition(x, 13.f);
#endif
        m_menu->addChild(btn);
        return btn;
    };

    m_start = mk("Start", "GJ_button_01.png", menu_selector(Panel::onStart), 30.f);
    m_pause = mk("Pause", "GJ_button_02.png", menu_selector(Panel::onPause), 30.f);
    m_resume = mk("Resume", "GJ_button_01.png", menu_selector(Panel::onResume), 30.f);
    m_stop = mk("Stop", "GJ_button_06.png", menu_selector(Panel::onStop), 98.f);
    m_clear = mk("Clear", "GJ_button_04.png", menu_selector(Panel::onClear), 166.f);

    this->refresh();
    return true;
}

void Panel::setLine(int i, std::string const& text, ccColor3B color) {
    if (m_cache[i] != text) {
        m_cache[i] = text;
        m_lines[i]->setString(text.c_str());
    }
    m_lines[i]->setColor(color);
}

void Panel::refresh() {
    auto& bot = Bot::get();

    this->setScale(kBaseScale * static_cast<float>(Mod::get()->getSettingValue<double>("panel-scale")));

    bool show = Mod::get()->getSettingValue<bool>("panel-visible");
    this->setVisible(show);
    if (!show) return;

    int op = static_cast<int>(Mod::get()->getSettingValue<int64_t>("panel-opacity"));
    op = std::max(10, std::min(100, op));
    m_bg->setOpacity(static_cast<GLubyte>(op * 255 / 100 * 8 / 10));
    GLubyte textOp = static_cast<GLubyte>(90 + op * 165 / 100);
    for (auto* l : m_lines) l->setOpacity(textOp);

    auto const& v = bot.vision;
    auto state = bot.state;

    // line 1: who is in control
    switch (state) {
        case BotState::Running: setLine(0, "BOT: RUNNING (learning)", {120, 255, 120}); break;
        case BotState::Paused: setLine(0, "BOT: PAUSED", {255, 220, 90}); break;
        case BotState::PlayerControl: setLine(0, "YOU'RE IN CONTROL (bot paused)", {255, 170, 60}); break;
        default: setLine(0, "BOT: STOPPED", {190, 190, 190}); break;
    }

    // line 2: mode + ground/air
    std::string l2 = fmt::format("Mode: {} - {}", v.mode, v.grounded ? "on ground" : "in the air");
    if (!v.supported) l2 += " (n/a)";
    setLine(1, l2);

    // line 3: what is ahead
    if (!v.supported) {
        setLine(2, "Sees: - (you play this part)");
    } else if (!v.hasTarget) {
        setLine(2, "Sees: clear road");
    } else {
        setLine(2, fmt::format("Sees: {} x{}, {:.0f}u away, {:.1f}w {:.1f}h",
                               v.hazard ? "hazard" : "block", v.count, v.dist, v.width / 30.f, v.height / 30.f));
    }

    // line 4: next action
    setLine(3, fmt::format("Next: {}", v.action));

    // line 5: attempts / best / now
    int attempts = bot.brain ? bot.brain->attempts : 0;
    float best = bot.brain ? bot.brain->best : 0.f;
    setLine(4, fmt::format("Attempt {} | Best {:.0f}% | Now {:.0f}%", attempts, best, v.nowPct));

    // line 6: what it has learned
    int sit = bot.brain ? bot.brain->situationsLearned() : 0;
    int jumps = bot.brain ? bot.brain->jumpSpotsLearned() : 0;
    setLine(5, fmt::format("Learned: {} situations, {} jump spots", sit, jumps));

    // buttons depend on the state
    bool stopped = state == BotState::Stopped;
    bool running = state == BotState::Running;
    auto show1 = [](CCMenuItemSpriteExtra* b, bool on) {
        b->setVisible(on);
        b->setEnabled(on);
    };
    show1(m_start, stopped);
    show1(m_pause, running);
    show1(m_resume, state == BotState::Paused || state == BotState::PlayerControl);
    show1(m_stop, !stopped);
    show1(m_clear, true);
}

void Panel::onStart(CCObject*) {
    Bot::get().start();
    this->refresh();
}

void Panel::onPause(CCObject*) {
    Bot::get().pause();
    this->refresh();
}

void Panel::onResume(CCObject*) {
    Bot::get().resume();
    this->refresh();
}

void Panel::onStop(CCObject*) {
    Bot::get().stop();
    this->refresh();
}

void Panel::onClear(CCObject*) {
    // Pause first so the bot isn't mid-jump while the popup is open.
    Bot::get().pause();
    this->refresh();
    createQuickPopup(
        "Clear memory",
        "Make the bot <cr>forget everything</c> it learned on this level?",
        "Cancel", "Forget",
        [this](auto*, bool forget) {
            if (forget) {
                Bot::get().clearMemory();
                this->refresh();
            }
        });
}
