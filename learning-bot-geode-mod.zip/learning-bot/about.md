# Learning Bot

A robot that plays your level and **learns from every attempt**.

- Press **Start** in the panel (bottom-left) to let it play. It never starts by itself.
- It only controls the **jump input**. Press jump yourself and it instantly hands control back to you.
- Its memory is saved per level. Press **Clear** to make it forget everything.
